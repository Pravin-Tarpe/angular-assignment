import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

  chartData: any[];
  
  grade1Count : number = 0;
  grade2Count : number = 0;
  grade3Count : number = 0;

  // options
  legendPosition: any = 'below';

  constructor( private router : Router,
               private service : StudentService ) { }

  ngOnInit(): void {

      this.service.getAllData().subscribe( res => {
        
        let totalRecords : number = res.length;
        let totalScore : number = 0;

        res.forEach( student => {
            for( let sub in student.marks)
              totalScore += student.marks[sub];

            if( totalScore > 320 ) this.grade1Count++;
            if( totalScore > 240 && totalScore <= 320 ) this.grade2Count++;
            if( totalScore < 240 ) this.grade3Count++;

            totalScore = 0;  //reset of next iteration
        })

        this.chartData = [
            { name : 'grade1', value : this.grade1Count / totalRecords * 100 },
            { name : 'grade2', value : this.grade2Count / totalRecords * 100 },
            { name : 'grade3', value : this.grade3Count / totalRecords * 100 },
          ]
      })  
  }


  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));

    let grade = data.name || data;
    this.router.navigateByUrl(`/details/${grade}`);
  }

}
