import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { StudentDetailsComponent } from './student-details/student-details.component';

const routes: Routes = [
  { path : '', component : PieChartComponent},
  { path : 'details/:grade', component : StudentDetailsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
