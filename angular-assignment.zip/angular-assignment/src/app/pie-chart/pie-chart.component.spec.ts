import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { StudentServiceStub } from 'src/stub/student-service.stub';
import { StudentService } from '../student.service';

import { PieChartComponent } from './pie-chart.component';

describe('PieChartComponent', () => {
  let component: PieChartComponent;
  let fixture: ComponentFixture<PieChartComponent>;

  const routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);

  beforeEach(async () => {

    await TestBed.configureTestingModule({
      declarations: [ PieChartComponent ],
      providers : [
        { provide : StudentService, useClass : StudentServiceStub },
        { provide : Router, useValue : routerSpy }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should initialize local field varibales', () => {

    expect(component.chartData).toBeTruthy();
    expect(component.grade1Count).toBe(1);
    expect(component.grade2Count).toBe(1);
    expect(component.grade3Count).toBe(1);
  })

  it('should tell ROUTER to navigate when hero clicked', () => {
    component.onSelect({ name : 'grade1'});  // trigger click 
  
    // args passed to router.navigateByUrl() spy
    const spy = routerSpy.navigateByUrl as jasmine.Spy;
    const navArgs = spy.calls.first().args[0];
  
    console.log(navArgs);
    expect(navArgs).toBe('/details/grade1');
  });
  
});
