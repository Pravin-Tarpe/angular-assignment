describe('PieChart tests', () => {
  it('Visits the initial project page', () => {
    cy.visit('/')
    cy.contains('% of students passed in 2018-2019 session');
  })

  it('should navigate to student-details page when clicked on Pie Chart', ()=> {
    cy.visit('/');
    cy.get('svg').click();
    cy.url().should('include', '/details');
  })

  it('should navigate to student-details page when clicked on chart legends', () => {
    cy.visit('/').visit
    cy.get('span.legend-label-text:contains("grade1")').click();
    cy.url().should('include', '/details/grade1');

    cy.visit('/').visit
    cy.get('span.legend-label-text:contains("grade2")').click();
    cy.url().should('include', '/details/grade2');

    cy.visit('/').visit
    cy.get('span.legend-label-text:contains("grade3")').click();
    cy.url().should('include', '/details/grade3');
  })

  it('should go back to Pie Chart when clicked on "Go to Pie Chart" link', () => {
    cy.visit('/details/grade1')
    cy.get('a').click();
    cy.url().should('include', '/')
  })

  it('should show email editor popup when double clicked on email grid cell', () => {
    cy.visit('/details/grade1')
    cy.get('div:contains("jack@gmail.com")').dblclick();
    cy.get('form input[type="email"]').should('include.value','jack@gmail.com')
  })

  it('should disable Save button in email editor when input is cleared', () => {
    cy.visit('/details/grade1')
    cy.get('div:contains("jack@gmail.com")').dblclick();
    cy.get('form input[type="email"]').clear();

    cy.get('form button:contains("Save")').should('not.be.enabled');
  })

  it('should validate the email input field when user edits it', () => {
    cy.visit('/details/grade1')
    cy.get('div:contains("jack@gmail.com")').dblclick();

    cy.get('form input[type="email"]').clear().type('jack.com');

    cy.get('form').contains('Please enter a valid email address');
  })

  it('should save the new email address when clicked on Save button', () => {
    cy.visit('/details/grade1')
    cy.get('div:contains("jack@gmail.com")').dblclick();

    let newEmail = 'jack123@gmail.com'
    cy.get('form input[type="email"]').clear().type(newEmail);
    cy.get('form button:contains("Save")').click();
    cy.contains(newEmail);
  })

  it('should not update the email when clicked on cancel button', () => {
    cy.visit('/details/grade1')
    cy.get('div:contains("jack@gmail.com")').dblclick();

    let newEmail = 'jack123@gmail.com';
    cy.get('form input[type="email"]').clear().type(newEmail);
    cy.get('form button:contains("Cancel")').click();
    cy.contains('jack@gmail.com');
  })
})
