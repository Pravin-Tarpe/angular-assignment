export interface Student {
    name : string,
    age : number,
    email : string,
    marks : {
        english : number,
        maths : number,
        science : number,
        socialStudies : number
    }
}