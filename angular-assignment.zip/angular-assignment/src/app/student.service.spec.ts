import { of } from 'rxjs';
import { StudentService } from './student.service';

describe('StudentService', () => {
  let httpClientSpy: { get: jasmine.Spy };
  let service: StudentService;

  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    service = new StudentService(httpClientSpy as any);
  });

  const expectedStudents = [
    {
      name: 'Jack', age: 16, email: 'jack@gmail.com',
      marks: { english: 70, maths: 70, science: 70, socialStudies: 70 },
    },
    {
      name: 'Smith', age: 16, email: 'smith@gmail.com',
      marks: { english: 90, maths: 90, science: 90, socialStudies: 90 },
    },
    {
      name: 'Mary', age: 16, email: 'mary@gmail.com',
      marks: { english: 40, maths: 40, science: 40, socialStudies: 40 },
    },
  ];

  it('should return expected students', () => {

    httpClientSpy.get.and.returnValue(of(expectedStudents));

    service.getAllData().subscribe((res) => {
      expect(res).toEqual(expectedStudents);
    });
  });

  it('should return student data gradewise', () => {

    httpClientSpy.get.and.returnValue(of(expectedStudents));
    
      service.getGradeWiseData('grade1').subscribe( res => {
        expect(res).toEqual([
          {
            name: 'Smith', age: 16, email: 'smith@gmail.com',
            marks: { english: 90, maths: 90, science: 90, socialStudies: 90 },
          }
        ])
      })
  })
});
