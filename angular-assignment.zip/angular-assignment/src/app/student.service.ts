import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { Student } from 'src/model/student';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  url: string = './assets/student-data.json';

  constructor(private http: HttpClient) {}

  getAllData() {
    return this.http.get<Student[]>(this.url);
  }

  getGradeWiseData(grade: string) {
    let total: number = 0;
    let filteredData : Student[] = [];

    return this.http
      .get<Student[]>(this.url).pipe(
        map((res) => {
          res.forEach((student) => {
            for (let sub in student.marks) 
              total += student.marks[sub];

            if (grade === 'grade1' && total > 320 )
              filteredData.push(student);

            if (grade === 'grade2' && (total > 240 && total <=320 ))
              filteredData.push(student);

            if (grade === 'grade3' && total < 240)
              filteredData.push(student);

            total = 0;   // reset for next iteration
          });

          return filteredData;
        })
      )
  }

}
