import { Component } from '@angular/core';

@Component({
  selector: 'app-email-editor',
  templateUrl: './email-editor.component.html',
  styleUrls: ['./email-editor.component.css']
})
export class EmailEditorComponent {

  value : string;
  startValue : string;
  params : any;

  constructor() { }

  agInit(params: any): void {
    this.value = params.value;
    this.startValue = params.value;
    this.params = params;
  }

  isPopup(): boolean {
    return true;
  }

  getValue(): any {
    return this.value;
  }

 onSave() {
  this.params.api.stopEditing();
 }

 onCancel() {
    this.value = this.startValue;
    this.params.api.stopEditing();
 }

}
