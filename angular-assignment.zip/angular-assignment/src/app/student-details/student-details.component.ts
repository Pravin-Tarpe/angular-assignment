import { Component, OnInit } from '@angular/core';
import { NumericEditorComponent } from '../numeric-editor/numeric-editor.component';
import { EmailEditorComponent } from '../email-editor/email-editor.component';
import { StudentService } from '../student.service';
import { ActivatedRoute } from '@angular/router';
import { Student } from 'src/model/student';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {

  rowData : Observable<Student[]>;
  columnDefs : any[];
  grade : string;
  header : string;

  constructor( private service : StudentService,
               private route : ActivatedRoute ) { }

  ngOnInit(): void {

    this.grade = this.route.snapshot.params['grade'];

    this.rowData = this.service.getGradeWiseData(this.grade);

    this.header = this.grade === 'grade1' ? 'First' :  this.grade === 'grade2' ? 'Second' : 'Third';
    
    this.columnDefs = [
      {
        headerName : `${this.header} Grade Students`,
        children : [
          { headerName: 'Name', field: 'name', width: 80, editable : false },
          { headerName: 'Email', field: 'email', width: 80, cellEditor : 'emailEditor' },
          { headerName: 'Age', field: 'age', width: 80 , cellEditor : 'numericEditor' },
        ]
      },
      {
        headerName : 'Marks: out of 100',
        children : [
          { headerName: 'English', field: 'marks.english', width: 80, cellEditor : 'numericEditor'},
          { headerName: 'Maths', field: 'marks.maths', width: 80, cellEditor : 'numericEditor'},
          { headerName: 'Science', field: 'marks.science', width: 80, cellEditor : 'numericEditor'},
          { headerName: 'Social Studies', field: 'marks.socialStudies', width: 80, cellEditor : 'numericEditor'}
        ]
      }
  ];
  } 

  frameworkComponents = {
    'numericEditor': NumericEditorComponent,
    'emailEditor' : EmailEditorComponent
  };

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }

}
