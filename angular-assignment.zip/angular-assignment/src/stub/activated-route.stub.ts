export class ActivatedRouteStub{
    
    constructor() {}
    
    snapshot = {
        params : {
            grade : 'grade1'
        }
    }
    
}