import { of } from "rxjs";
import { Student } from "src/model/student";

export class StudentServiceStub {
    url : string;

    studentData : Student[]= [
        {
          name: 'Smith', age: 16, email: 'smith@gmail.com',
          marks: { english: 90, maths: 90, science: 90, socialStudies: 90 },
        },
        {
          name: 'Jack', age: 16, email: 'jack@gmail.com',
          marks: { english: 70, maths: 70, science: 70, socialStudies: 70 },
        },
        {
          name: 'Mary', age: 16, email: 'mary@gmail.com',
          marks: { english: 40, maths: 40, science: 40, socialStudies: 40 },
        },
      ];

    getAllData() {
        return of(this.studentData);
    }

    getGradeWiseData( grade : string) {
        if( grade === 'grade1')
            return of([{
                name: 'Smith', age: 16, email: 'smith@gmail.com',
                marks: { english: 90, maths: 90, science: 90, socialStudies: 90 },
              }]);

        if( grade === 'grade2')
              return of([{
                name: 'Jack', age: 16, email: 'jack@gmail.com',
                marks: { english: 70, maths: 70, science: 70, socialStudies: 70 },
              }]);

        if( grade === 'grade3')
              return of([{
                name: 'Mary', age: 16, email: 'mary@gmail.com',
                marks: { english: 40, maths: 40, science: 40, socialStudies: 40 },
              }]);
              
        return null;
    }
}