import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { AgGridModule } from 'ag-grid-angular';
import { ActivatedRouteStub } from 'src/stub/activated-route.stub';
import { RouterLinkDirectiveStub } from 'src/stub/router-link.directive.stub';
import { StudentServiceStub } from 'src/stub/student-service.stub';
import { EmailEditorComponent } from '../email-editor/email-editor.component';
import { NumericEditorComponent } from '../numeric-editor/numeric-editor.component';
import { StudentService } from '../student.service';

import { StudentDetailsComponent } from './student-details.component';

describe('StudentDetailsComponent', () => {
  let component: StudentDetailsComponent;
  let fixture: ComponentFixture<StudentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        AgGridModule.withComponents([ NumericEditorComponent, EmailEditorComponent ])
    ],
      declarations: [ StudentDetailsComponent, NumericEditorComponent, EmailEditorComponent ],
      providers : [ 
        RouterLinkDirectiveStub,
        { provide : StudentService, useClass : StudentServiceStub }, 
        { provide : ActivatedRoute, useClass : ActivatedRouteStub } 
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should initialize the local field variable', () => {
    component.ngOnInit();
    
    expect( component.grade).toBe('grade1');
    expect( component.header).toBe('First');
    expect( component.columnDefs).toBeTruthy();
    expect( component.rowData).toBeTruthy();
  })

  it('the grid cells should be as expected', () => {

    let service = TestBed.inject(StudentService);
    component.rowData = service.getGradeWiseData('grade2');
    fixture.detectChanges();

    const appElement = fixture.nativeElement;
    const cellElements = appElement.querySelectorAll('.ag-cell-value');

    expect(cellElements.length).toEqual(7);
    expect(cellElements[0].textContent).toEqual("Jack");
    expect(cellElements[1].textContent).toEqual("jack@gmail.com");
    expect(cellElements[2].textContent).toEqual('16');
    expect(cellElements[3].textContent).toEqual('70');
    expect(cellElements[4].textContent).toEqual('70');
    expect(cellElements[5].textContent).toEqual('70');
    expect(cellElements[6].textContent).toEqual('70');
  });

  it('should have a link to PieChart component', ()=> {

    let link = fixture.debugElement.query(By.css('a')).nativeElement.getAttribute('routerLink');
    expect(link).toEqual('/');
  })

});
