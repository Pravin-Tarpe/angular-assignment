import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AgGridModule } from 'ag-grid-angular';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmailEditorComponent } from './email-editor/email-editor.component';
import { NumericEditorComponent } from './numeric-editor/numeric-editor.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { StudentDetailsComponent } from './student-details/student-details.component';

@NgModule({
  declarations: [
    AppComponent,
    PieChartComponent,
    StudentDetailsComponent,
    NumericEditorComponent,
    EmailEditorComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    NgxChartsModule,
    AgGridModule.withComponents({
      NumericEditorComponent,
      EmailEditorComponent
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
