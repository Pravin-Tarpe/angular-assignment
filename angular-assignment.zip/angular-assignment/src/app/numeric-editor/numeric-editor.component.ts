import { Component } from '@angular/core';

@Component({
  selector: 'app-numeric-editor',
  templateUrl: './numeric-editor.component.html',
  styleUrls: ['./numeric-editor.component.css']
})
export class NumericEditorComponent {

  value : number;
  startValue : number;
  params : any;
  cancelBeforeStart : boolean = false;

  constructor() { }

  agInit(params: any): void {
    this.value = params.value;
    this.startValue = params.value;
    this.params = params;

    // only start edit if key pressed is a number, not a letter
    this.cancelBeforeStart =
      params.charPress && '1234567890'.indexOf(params.charPress) < 0;
  }

  isPopup(): boolean {
    return true;
  }

  getValue(): any {
    return this.value;
  }

  isCancelBeforeStart(): boolean {
    return this.cancelBeforeStart;
  }

  isCancelAfterEnd(): boolean {
    return this.value === 0;
  }

  onSave() {
    this.params.api.stopEditing();
  }

  onCancel() {
    this.value = this.startValue;
    this.params.api.stopEditing();
  }

}
